## SERVICES PHOTOGRAPHES

1. Lien de connexion vers le panneau administratif
`php artisan serve` et tapez ceci dans un nouveau terminal `npm run dev`
2. Ouvrez le navigateur et aller à l'adresse: 127.0.0.1:8000/admin
3. Entrer ces valeurs: email address: admin@admin.com  password: arielnana020596

## À chaque git pull, faire ceci
1. `composer install` et `npm install`
2. `php artisan migrate`
3. `php artisan optimize:clear` pour nettoyer le système de cache des vues


## Portée du projet restant
1. Gestion des disponibilitées (déjà fait)
2. Gestion des rendez-vous (clients -> photographe) (déjà fait)
3. Messagerie interne (client -> photographe)
4. Parcours du site (annonces, services, affichage detail annonce, service et contact de leurs auteurs) (deja fait)
5. C'est tout !
